from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:30339' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            create_data = self.database.animals.insert_one(data)  # data should be dictionary
            print(create_data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD.
    def read(self, search):
        if search is not None:
            read_data = list(self.database.animals.find(search, {"_id":False}))
            return read_data
        else:
            raise Exception("Nothing to read, because search parameter is empty")
            return False
    
# Method to implement the U in CRUD
    def update(self, new_data, updated_data):
        if new_data is not None:
            update_data = self.database.animals.update_one(new_data, updated_data)
            return True
        else:
            return False

# Method to implement the D in CRUD
    def delete(self, delete_data):
        if delete_data is not None:
            deleted_data = self.database.animals.delete_one(delete_data)
            return True
        else:
            return False